window.FIREBASE_CONFIG = {
  apiKey: "AIzaSyAaF2fdJBi1r9IKlJgr-OMcoQ4WrKVmzfw",
  authDomain: "kaja-namaj.firebaseapp.com",
  projectId: "kaja-namaj",
  storageBucket: "kaja-namaj.firebasestorage.app",
  messagingSenderId: "1059553801755",
  appId: "1:1059553801755:web:1045964a76aba25fbdeabe"
};
